

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class User
 */
@WebServlet("/User")
public class User extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=null;
		Statement ps=null;
		ResultSet rs = null;
		PrintWriter out=response.getWriter(); 
        
        String nm=request.getParameter("name");
        String pswd = request.getParameter("upass");
       String stat="";
        boolean st=false;
        
        response.setContentType("text/html");
        try
        {
        	Class.forName("com.mysql.jdbc.Driver");
        	out.print("Driver");
        	 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
        	 out.print("connected");
        	 ps =con.createStatement();
        	 String query="SELECT * FROM Login WHERE Username = '"+nm+"' and Password ='"+pswd+"' ";
        	 rs =ps.executeQuery(query);
             out.println("query executed");
             while(rs.next())
             {
            	 st=true;
            	 stat=rs.getString("status");
            	 //response.sendRedirect("UserDetails.html");
             }
             if(stat.equals("s"))
             {
            	 response.sendRedirect("UserDetails.html");	            	 
             }
          }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        }
	}

}
