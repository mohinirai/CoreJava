create table EMPLOYEE (ID NUMBER(22), NAME VARCHAR2(20))
insert into EMPLOYEE (ID,NAME) values(null,'abc')
insert into EMPLOYEE (ID,NAME) values(null,'def')
